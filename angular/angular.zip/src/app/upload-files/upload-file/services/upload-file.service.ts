import { Injectable } from '@angular/core';
import { AbstractUploadFileViewService } from './upload-file.abstract.service';

@Injectable()
export class UploadFileViewService extends AbstractUploadFileViewService {}
