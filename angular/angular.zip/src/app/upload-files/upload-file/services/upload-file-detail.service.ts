import { Injectable } from '@angular/core';
import { AbstractUploadFileDetailViewService } from './upload-file-detail.abstract.service';

@Injectable()
export class UploadFileDetailViewService extends AbstractUploadFileDetailViewService {}
