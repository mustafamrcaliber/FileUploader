
export interface DownloadTokenResultDto extends DownloadTokenResultDtoBase {
}

export interface DownloadTokenResultDtoBase {
  token?: string;
}
