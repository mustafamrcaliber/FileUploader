import { Component } from '@angular/core';

@Component({
  selector: 'abp-cookie-policy',
  templateUrl: './cookie-policy.component.html',
})
export class CookiePolicyComponent {
  constructor() {}
}
