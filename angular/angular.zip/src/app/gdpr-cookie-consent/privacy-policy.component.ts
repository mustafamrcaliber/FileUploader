import { Component } from '@angular/core';

@Component({
  selector: 'abp-privacy-policy',
  templateUrl: './privacy-policy.component.html',
})
export class PrivacyPolicyComponent {
  constructor() {}
}
